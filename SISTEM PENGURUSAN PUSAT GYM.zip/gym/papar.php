<?php
include('config.php');
$sql="SELECT * from ahli"; // mengambil semua data di dalam table ahli 
$result=mysql_query($sql)or die(mysql_error());
?>

<style>
	
body {
	background-image: url("wall.jpg");
	background-size: cover;
	font-family: monospace;
	color: 	#40E0D0;
	font-size: 18px;
}

.tambah {
	padding: 10px;
	color: #40E0D0;
	background-color: black;
	border: 2px solid ;
	width: 150px;
	border-radius: 4px;
	opacity: 0.8;
}


div {
	border: 2px solid black;
	width: 400px;
	padding: 20px;
	background-color: black;
	opacity: 0.9;
	border-radius: 5px;
}

table {

	border: 2px;
	border-collapse: collapse;
	padding: 10px;
	background-color: black;
	opacity: 0.8;

}

</style>


<center>
    <br><br>
<table width="500"> <!-- membuat table untuk memaparkan data -->
<tr>
<td align="center" bgcolor="black"><strong> Nama </strong></td> 
<td align="center"><strong> No Kad Pengenalan </strong></td>
<td align="center"><strong> Umur </strong></td>
</tr>

<?php
while ($row=mysql_fetch_array($result))
{
 echo"<tr>";
 echo"<td> <center>".$row["nama"]."</td>";
 echo"<td> <center>".$row["nokp"]."</td>";
 echo"<td> <center>".$row["umur"]."</td>";
}
 echo"</table>";
 echo"<center>";
 echo"<br>";
?>
</table>
<a href="form.php"><button class="tambah"> Tambah Ahli </button></a> <!-- button untuk menambah bilangan ahli -->
</br>
</center>
</body>
</head>
</html>