<html>
<head><title> Login </title></head>

<style>
	
body {
	background-image: url("wall.jpg");
	background-size: cover;
	font-family: monospace;
	color: 	#40E0D0;
	font-size: 18px;
}

.img {
	opacity: 0.8;
	margin-top: 150px;
}

[type=text] {
	border: 2px solid #40E0D0;
	padding: 5px;
	border-radius: 4px;
}

[type=number] {
	border: 2px solid #40E0D0;
	padding: 5px;
	border-radius: 4px;
}

[type=submit] {
	padding: 10px;
	color: #40E0D0;
	background-color: black;
	border: 2px solid;
	width: 150px;
	opacity: 0.8;
	border-radius: 4px;
}

[type=submit]:hover {
	padding: 10px;
	color: #40E0D0;
	background-color: grey;
	border: 2px solid;
	width: 150px;
}


table {
	border: 2px solid black;
	width: 450px;
	padding: 20px;
	background-color: black;
	opacity: 0.9;
	border-radius: 5px;
	align-items: center;

}


</style>

<body><center>

	<form action="pros_insert.php" method="post" > <!-- menggunakan coding untuk proses memasukkan data ke dalam form -->
	<table width="" border="0">
  
  <img src="form.png" width="180" height="180" class="img"><!-- menetapkan size imej -->
  <tr>
  <th scope="col"> Nama : </th>
  <th scope="col"><div align="left">
  <input type="text" name="nama" value="" size="30"/>
  </div>
  </th>
  </tr>

  <tr>
  <th scope="col"> No ic :</th>
  <th scope="col"><div align="left">
  <input type="text" name="nokp" value="" size="30"/>
  </div>
  </th>
  </tr>

  <tr>
  <th scope="col"> Umur : </th>
  <th scope="col"><div align="left">
  <input type="number" name="umur" value="" size="10"/>
  </div>
  </th>
  </tr>
</table><br>

  <input type="submit" name="submit"> <!-- memasukkan button submit untuk memasukkan data kedalam form -->



</center>
</body>