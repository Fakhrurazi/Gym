<html>
<head><title> Login </title></head>

<style>
	
body {
	background-image: url("wall.jpg");
	background-size: cover;
	font-family: monospace;
	color: 	#40E0D0;
	font-size: 18px;
}
form {
	margin-top: 200px;
}

[type=submit] {
	padding: 10px;
	color: #40E0D0;
	background-color: grey;
	border: 2px solid;
	width: 150px;
}
[type=reset] {
	padding: 10px;
	color: #40E0D0;
	background-color: grey;
	border: 2px solid ;
	width: 150px;
}

[type=text] {
	border: 2px solid #40E0D0;
	padding: 5px;
	border-radius: 4px;
}

[type=password] {
	border: 2px solid #40E0D0;
	padding: 5px;
	border-radius: 4px;
}

div {
	border: 2px solid black;
	width: 400px;
	padding: 20px;
	background-color: black;
	opacity: 0.9;
	border-radius: 5px;
}

.img {
	opacity: 0.8;
}

</style>

<body><center>
	
	<form action="pros_login.php" method="post" > 
		<!-- proses yang digunakan di dalam form tersebut -->

		<img src="logo.png" width="200" height="200" class="img">
		<br>
		<div>
		<p> Username : <input type="text" name="name" placeholder=" Username "></p> <!-- meletakkan textbox untuk user memasukkan nama -->
		<p> Password : <input type="password" name="password" placeholder=" Password "></p><!-- meletakkan password untuk user memasukkan password -->
		<input type="submit" name=""> 
		<input type="reset" name="">
		</div>
	</form>


</center>
</body>