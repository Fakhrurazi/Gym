<?php
include ('config.php');

$hari=$_POST['hari'];
$nama=$_POST['nama'];
$ic=$_POST['ic'];
$sewa=$_POST['sewa'];
$pulang=$_POST['pulang'];

echo"<br>";
$query="insert into axia values
('$hari','$nama','$ic','$sewa','$pulang')";
if(mysql_query($query)){
header("Location:index.php");}
else
header("Location:form.php");;

?>