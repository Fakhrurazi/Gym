<?php
include ('config.php');

$nama=$_POST['nama'];
$nokp=$_POST['nokp'];
$umur=$_POST['umur'];

echo"<br>";
$query="insert into ahli values
('$nama','$nokp','$umur')";
if(mysql_query($query)){
header("Location:papar.php");}
else
header("Location:form.php");;

?>