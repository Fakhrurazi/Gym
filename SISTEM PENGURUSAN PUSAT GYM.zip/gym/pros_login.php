<?php
include ('config.php');

$name=$_POST['name'];
$password=$_POST['password'];

echo"<br>";
$query="insert into login values
('$name','$password')";
if(mysql_query($query)){
header("Location:form.php");}
else
echo" Salah ";

?>